'use client'

import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

type Order = {
  id: string
  order_number: string | null
  customer_name: string | null
  total_amount: number | null
  status: string | null
  created_at: string
}

export default function Dashboard() {
  const [orders, setOrders] = useState<Order[]>([])
  const [productCount, setProductCount] = useState(0)
  const [orderCount, setOrderCount] = useState(0)
  const [pendingCount, setPendingCount] = useState(0)
  const [sales, setSales] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    async function loadDashboard() {
      const today = new Date()
      today.setHours(0, 0, 0, 0)
      const todayStart = today.toISOString()

      const [products, allOrders, pendingOrders, todayOrders, latestOrders] = await Promise.all([
        supabase.from('products').select('*', { count: 'exact', head: true }),
        supabase.from('orders').select('*', { count: 'exact', head: true }),
        supabase.from('orders').select('*', { count: 'exact', head: true }).eq('status', 'pending'),
        supabase.from('orders').select('total_amount').gte('created_at', todayStart),
        supabase.from('orders')
          .select('id, order_number, customer_name, total_amount, status, created_at')
          .order('created_at', { ascending: false }).limit(5)
      ])

      const firstError = products.error || allOrders.error || pendingOrders.error || todayOrders.error || latestOrders.error
      if (firstError) {
        setError(firstError.message)
      } else {
        setProductCount(products.count ?? 0)
        setOrderCount(allOrders.count ?? 0)
        setPendingCount(pendingOrders.count ?? 0)
        setSales((todayOrders.data ?? []).reduce((sum, item) => sum + Number(item.total_amount ?? 0), 0))
        setOrders((latestOrders.data ?? []) as Order[])
      }
      setLoading(false)
    }

    loadDashboard()
  }, [])

  return (
    <main className="shell">
      <aside className="sidebar">
        <div className="brand"><div className="logo">ပ</div><div><b>ပဉ္စရာ</b><small>PYINSARA ADMIN</small></div></div>
        <nav>
          <a className="active">▦　Dashboard</a>
          <a>▣　Order များ</a>
          <a>□　ကုန်ပစ္စည်းများ</a>
          <a>▤　အမျိုးအစားများ</a>
          <a>♧　Customer များ</a>
          <a>◎　ငွေပေးချေမှု</a>
          <a>▱　ပို့ဆောင်မှု</a>
          <a>⚙　ဆက်တင်များ</a>
        </nav>
        <small className="sidefoot">ထွန်းအမှုန့်စုံ · Pyinsara</small>
      </aside>
      <section className="content">
        <header><div><small>ထွန်းအမှုန့်စုံ / စီမံခန့်ခွဲမှု</small><h1>မင်္ဂလာပါ 👋</h1><p>ပဉ္စရာ Online Shop Dashboard မှ ကြိုဆိုပါတယ်။</p></div></header>
        <div className="notice"><b>Pyinsara Admin</b><span>Supabase Database မှ အချက်အလက်များ</span></div>
        {error && <p className="error">Database အမှား: {error}</p>}
        <div className="stats">
          <article className="stat"><span>🛍️</span><small>စုစုပေါင်း Order</small><strong>{loading ? '...' : orderCount}</strong></article>
          <article className="stat"><span>⏳</span><small>စောင့်ဆိုင်းနေသော Order</small><strong>{loading ? '...' : pendingCount}</strong></article>
          <article className="stat"><span>📦</span><small>ကုန်ပစ္စည်း</small><strong>{loading ? '...' : productCount}</strong></article>
          <article className="stat"><span>💰</span><small>ယနေ့ရောင်းအား</small><strong>{loading ? '...' : sales.toLocaleString() + ' ကျပ်'}</strong></article>
        </div>
        <h2>နောက်ဆုံး Order များ</h2>
        <div className="tablewrap"><table><thead><tr><th>Order နံပါတ်</th><th>Customer</th><th>စုစုပေါင်း</th><th>အခြေအနေ</th></tr></thead>
          <tbody>{loading ? <tr><td colSpan={4}>Loading...</td></tr> : orders.length === 0 ? <tr><td colSpan={4}>Order အသစ် မရှိသေးပါ</td></tr> : orders.map(order => <tr key={order.id}><td>{order.order_number || '—'}</td><td>{order.customer_name || 'Customer'}</td><td>{Number(order.total_amount ?? 0).toLocaleString()} ကျပ်</td><td>{order.status || 'မသတ်မှတ်ရသေး'}</td></tr>)}</tbody>
        </table></div>
        <footer>© 2026 Pyinsara · ထွန်းအမှုန့်စုံ</footer>
      </section>
    </main>
  )
}
