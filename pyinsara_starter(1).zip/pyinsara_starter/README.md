# Pyinsara Starter

ပဉ္စရာ (Pyinsara) online shop starter project.

## လိုအပ်ချက်
- Node.js 20+
- Supabase project

## စတင်ရန်
1. ZIP ကို extract လုပ်ပါ။
2. Terminal မှ `cd admin` လုပ်ပါ။
3. `npm install` လုပ်ပါ။
4. `admin/.env.local.example` ကို `.env.local` ဟု copy လုပ်ပြီး Supabase URL နှင့် publishable/anon key ထည့်ပါ။
5. `npm run dev` လုပ်ပါ။

ဒီ ZIP သည် စတင်တည်ဆောက်ရန် starter သာဖြစ်ပြီး ပြည့်စုံသော shopping app မဟုတ်သေးပါ။
Supabase project အသစ် မဖန်တီးပါနှင့်—ရှိပြီးသား project ကို ဆက်သုံးနိုင်ပါသည်။
