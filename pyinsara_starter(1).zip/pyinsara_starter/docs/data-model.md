# Pyinsara data model

အဓိက tables: categories, products, profiles, orders, order_items, payment_proofs, admin_users.
ငွေကြေးကို MMK ဖြင့် သိမ်းဆည်းရန် ရည်ရွယ်ထားသည်။
