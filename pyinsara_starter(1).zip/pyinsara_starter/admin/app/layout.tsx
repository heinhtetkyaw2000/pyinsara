import './style.css'

export const metadata = {
  title: 'Pyinsara Admin',
  description: 'ပဉ္စရာ Online Shop Admin'
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="my">
      <body>{children}</body>
    </html>
  )
}
